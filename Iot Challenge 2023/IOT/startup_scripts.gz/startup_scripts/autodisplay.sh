#!/bin/sh
#*************************************************
#         (c) Keysight Technologies 2020 
#
# PROPRIETARY RIGHTS of Keysight Technologies are 
# involved in the subject matter of this software. 
# All manufacturing, reproduction, use, and sales 
# rights pertaining to this software are governed 
# by the license agreement. The recipient of this 
# code implicitly accepts the terms of the license. 
#
#**************************************************
#
# File Name  : autodisplay.sh
# DESCRIPTION: This compiles the startup.c code and places it in /etc/init.d
#              startup.sh is then copied and changed ot executable in the same dir
#              Any old links of the start up script are removed.
#              The startup scipt is added to the rc5.d table as the last process
#              to start on boot in rc5.d (init 5 level)
#**************************************************/
gcc startup.c -l mraa -o /etc/init.d/startup
cp startup.sh /etc/init.d/.
chmod 755 /etc/init.d/startup.sh
update-rc.d -f startup.sh remove
rm /etc/rc5.d/S99startup.sh 2> /dev/null
update-rc.d startup.sh defaults 99
ln -s /etc/init.d/startup.sh /etc/rc5.d/S99startup.sh
