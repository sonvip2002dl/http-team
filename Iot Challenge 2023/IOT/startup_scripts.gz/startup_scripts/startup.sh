#!/bin/sh
#*************************************************
#         © Keysight Technologies 2019 
#
# PROPRIETARY RIGHTS of Keysight Technologies are 
# involved in the subject matter of this software. 
# All manufacturing, reproduction, use, and sales 
# rights pertaining to this software are governed 
# by the license agreement. The recipient of this 
# code implicitly accepts the terms of the license. 
#
#**************************************************
#
# FILE NAME  :  startup.sh      
# DESCRIPTION:  This code starts up the complied code in the /etc/init.d/startup
#               This puts the program into the background incase the code
#               does not end right away
#*************************************************/
/etc/init.d/startup &
