﻿namespace LoRa
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRx = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lblComPort = new System.Windows.Forms.Label();
            this.txtComPort = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.logLabel = new System.Windows.Forms.TextBox();
            this.txtFreq = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnTx = new System.Windows.Forms.Button();
            this.txtTxSignal = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRx
            // 
            this.btnRx.Location = new System.Drawing.Point(156, 309);
            this.btnRx.Margin = new System.Windows.Forms.Padding(4);
            this.btnRx.Name = "btnRx";
            this.btnRx.Size = new System.Drawing.Size(122, 28);
            this.btnRx.TabIndex = 0;
            this.btnRx.Text = "Start Receive";
            this.btnRx.UseVisualStyleBackColor = true;
            this.btnRx.Click += new System.EventHandler(this.btnRx_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(281, 309);
            this.btnStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(93, 28);
            this.btnStop.TabIndex = 3;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.Location = new System.Drawing.Point(28, 18);
            this.lblComPort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(117, 17);
            this.lblComPort.TabIndex = 3;
            this.lblComPort.Text = "Device ComPort :";
            // 
            // txtComPort
            // 
            this.txtComPort.Location = new System.Drawing.Point(156, 15);
            this.txtComPort.Margin = new System.Windows.Forms.Padding(4);
            this.txtComPort.Name = "txtComPort";
            this.txtComPort.Size = new System.Drawing.Size(85, 22);
            this.txtComPort.TabIndex = 4;
            this.txtComPort.Text = "COM9";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(260, 12);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(115, 28);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.logLabel);
            this.groupBox1.Location = new System.Drawing.Point(28, 81);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(347, 191);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LoRa Log";
            // 
            // logLabel
            // 
            this.logLabel.Location = new System.Drawing.Point(11, 22);
            this.logLabel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logLabel.Multiline = true;
            this.logLabel.Name = "logLabel";
            this.logLabel.ReadOnly = true;
            this.logLabel.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.logLabel.Size = new System.Drawing.Size(329, 153);
            this.logLabel.TabIndex = 0;
            // 
            // txtFreq
            // 
            this.txtFreq.Location = new System.Drawing.Point(156, 52);
            this.txtFreq.Margin = new System.Windows.Forms.Padding(4);
            this.txtFreq.Name = "txtFreq";
            this.txtFreq.Size = new System.Drawing.Size(85, 22);
            this.txtFreq.TabIndex = 8;
            this.txtFreq.Text = "433050000";
            this.txtFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Frequency :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 55);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Hz";
            // 
            // btnTx
            // 
            this.btnTx.Location = new System.Drawing.Point(28, 309);
            this.btnTx.Margin = new System.Windows.Forms.Padding(4);
            this.btnTx.Name = "btnTx";
            this.btnTx.Size = new System.Drawing.Size(122, 28);
            this.btnTx.TabIndex = 10;
            this.btnTx.Text = "Start Transmit";
            this.btnTx.UseVisualStyleBackColor = true;
            this.btnTx.Click += new System.EventHandler(this.btnTx_Click);
            // 
            // txtTxSignal
            // 
            this.txtTxSignal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTxSignal.Location = new System.Drawing.Point(28, 279);
            this.txtTxSignal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTxSignal.Name = "txtTxSignal";
            this.txtTxSignal.Size = new System.Drawing.Size(122, 24);
            this.txtTxSignal.TabIndex = 12;
            this.txtTxSignal.Text = "1234";
            this.txtTxSignal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 354);
            this.Controls.Add(this.txtTxSignal);
            this.Controls.Add(this.btnTx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFreq);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtComPort);
            this.Controls.Add(this.lblComPort);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnRx);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "LoRa";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRx;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lblComPort;
        private System.Windows.Forms.TextBox txtComPort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox logLabel;
        private System.Windows.Forms.TextBox txtFreq;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnTx;
        private System.Windows.Forms.TextBox txtTxSignal;
    }
}

