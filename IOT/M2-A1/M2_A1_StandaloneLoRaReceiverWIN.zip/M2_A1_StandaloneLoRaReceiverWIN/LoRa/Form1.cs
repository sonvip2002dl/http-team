﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Timers;
using System.IO;

namespace LoRa
{
    public partial class Form1 : Form
    {
        private SerialPort _serialPort = null;
        private bool _deviceConnected = false;
        private bool _transmit = false;
        private bool _startRead = false;
        static System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();

        /// <summary>
        /// Initialize windows form
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            //setup timers for repeated command
            myTimer.Interval = 5000;
            myTimer.Tick += new EventHandler(TimerTransmitEventProcessor);

            //update UI control
            btnTx.Enabled = false;
            btnRx.Enabled = false;
            btnStop.Enabled = false;
            txtComPort.Enabled = true;
            txtTxSignal.Enabled = false;
        }
        
        /// <summary>
        /// Connects to the serial COM port specified
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (!_deviceConnected)
            {
                try
                {
                    _serialPort = new SerialPort();
                    _serialPort.PortName = txtComPort.Text;
                    _serialPort.BaudRate = 57600;
                    _serialPort.StopBits = StopBits.One;
                    _serialPort.DataBits = 8;
                    _serialPort.Parity = Parity.None;
                    _serialPort.Handshake = Handshake.None;
                    _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
                    _serialPort.Open();
                    _serialPort.ReadTimeout = 20000;
                    _serialPort.WriteTimeout = 20000;
                    _deviceConnected = true;

                    //Update UI control
                    btnTx.Enabled = true;
                    btnRx.Enabled = true;
                    btnStop.Enabled = false;
                    btnConnect.Text = "Disconnect";
                    Log("Connected");
                    txtComPort.Enabled = false;
                    txtTxSignal.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                    }
                }                
            }
            else //if(_deviceConnected)
            {
                if (_serialPort!= null)
                {
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                    }
                }
                _serialPort = null;
                _deviceConnected = false;

                //Update UI control
                btnTx.Enabled = false;
                btnRx.Enabled = false;
                btnStop.Enabled = false;
                btnConnect.Text = "Connect";
                Log("Disconnected");
                txtComPort.Enabled = true;
                txtTxSignal.Enabled = false;
            }
        }

        /// <summary>
        /// When Start button is clicked, initializes the LoRa device for transmitting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTx_Click(object sender, EventArgs e)
        {
            try
            {
                string freq = "radio set freq " + txtFreq.Text;
                LoRaCommand("radio cw off");        // reset LoRa
                LoRaCommand(freq);
                LoRaCommand("mac pause");
                myTimer.Start();
                _transmit = true;
                _startRead = true;

                //Update UI control
                btnTx.Enabled = false;
                btnRx.Enabled = false;
                btnStop.Enabled = true;
                txtComPort.Enabled = true;
                txtTxSignal.Enabled = true;
                btnConnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Exception error occurred: {0}", ex.Message));
            }
        }

        /// <summary>
        /// When Start button is clicked, initializes the LoRa device for receiving
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRx_Click(object sender, EventArgs e)
        {
            try
            {
                string freq = "radio set freq " + txtFreq.Text;
                LoRaCommand("radio cw off");        // reset LoRa
                LoRaCommand(freq);
                LoRaCommand("mac pause");
                LoRaCommand("radio set wdt 0");
                LoRaCommand("radio rx 0");
                //Thread thr = new Thread(RxCommand);
                //thr.Start();
                _transmit = false;
                _startRead = true;

                //Update UI control
                btnTx.Enabled = false;
                btnRx.Enabled = false;
                btnStop.Enabled = true;
                txtComPort.Enabled = true;
                txtTxSignal.Enabled = false;
                btnConnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Exception error occurred: {0}", ex.Message));
            }
        }
        
        /// <summary>
        /// When Stop button is clicked, stops receiving data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (_transmit)      // Stops timer processor for transmit
                {
                    myTimer.Stop();
                }
                _startRead = false;

                //Update UI control
                btnTx.Enabled = true;
                btnRx.Enabled = true;
                btnStop.Enabled = false;
                txtTxSignal.Enabled = true;
                btnConnect.Enabled = true;
                Log("LoRa stopped");
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Exception error occurred: {0}", ex.Message));
            }
        }

        /// <summary>
        /// This command sends LoRa commands to the LoRa device and appends it with a carriage return
        /// </summary>
        /// <param name="command">Specify the command you wish to send to the device</param>
        private void LoRaCommand(string command)
        {
            try {
                _serialPort.Write(string.Format("{0}\r\n", command));
                Log(command);
                Thread.Sleep(500);      // Wait for commands to get through
                string status = _serialPort.ReadLine();
                Log(status);
            }
            catch (TimeoutException)
            {
                // to catch read serial port timeouts
            }
            catch (Exception)
            {
                // to catch any other exceptions related to read serial port
            }

            try
            {
                _serialPort.DiscardInBuffer();
            }
            catch (Exception)
            {

            }
        }

        public void TimerTransmitEventProcessor(Object myObject, EventArgs myEventArgs)
        {
            string txSignal = "radio tx " + txtTxSignal.Text;
            LoRaCommand(txSignal);
        }

        /// <summary>
        /// Listens to the serial port for any incoming data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            if (_startRead)
            {
                SerialPort sp = (SerialPort)sender;
                string indata = "";
                Thread.Sleep(500);     //Wait for complete signal to enter buffer

                try
                {
                    indata = sp.ReadExisting();
                }
                catch (Exception)
                {

                }

                Log(indata);
                if (indata.Contains("err"))
                {
                    EventArgs err = new EventArgs();
                    btnRx_Click(this, err);
                }

                if (indata.Contains("_rx"))
                {
                    LoRaCommand("radio rx 0");
                    //Thread thr = new Thread(RxCommand);
                    //thr.Start();
                }

                try
                {
                    _serialPort.DiscardInBuffer();
                }
                catch (Exception)
                {

                }
            }
        }

        /// <summary>
        /// Logs and displays the send and receive commands to and from the LoRa device
        /// </summary>
        /// <param name="data"></param>
        private void Log(string data)
        {
            string curText = logLabel.Text;
            string newText;
            int numChar = curText.Length;
            int index = 0;
            int count = curText.Count(x => x == '\n');
            int maxLines = 100;     // To avoid textbox overflowing

            if (count > maxLines + 1)
            {
                count = count - maxLines + 1;

                while (count > 0)
                {
                    if (curText[index] == '\n')
                    {
                        count = count - 1;
                    }

                    index++;
                }

                newText = curText.Substring(index, numChar - index);
            }
            else
            {
                newText = curText;
            }

            SetText(data);
        }

        /// <summary>
        /// Ensures only one thread is updating the Log
        /// </summary>
        /// <param name="text"></param>
        delegate void SetTextCallback(string text);
        private void SetText(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.logLabel.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.logLabel.AppendText(text);
                this.logLabel.AppendText("\n");
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (_serialPort != null)
                {
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                    }
                }
                _serialPort = null;
                _deviceConnected = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Exception error occurred: {0}", ex.Message));

            }
        }

        /// <summary>
        /// Starts a new thread to send Rx command to the LoRa device. This allows the
        /// previous Rx data to be received completely before a new Rx command is sent
        /// </summary>
        private void RxCommand()
        {
            //Thread.Sleep(2000);
            if (_startRead) { LoRaCommand("radio rx 0"); }

            try
            {
                _serialPort.DiscardInBuffer();
            }
            catch (Exception)
            {

            }
        }
    }
}
